pacman::p_load("writexl", "readxl", "readr", "dplyr", "tidyr", "tidyverse", "ggplot2", "stringr")

dir.create("C:/Users/danie/Projetos R/Fapesp/frente 3/EBBC/muhsen")
setwd("C:/Users/danie/Projetos R/Fapesp/frente 3/EBBC/muhsen")

# Chamando arquivos
base_orcid_2020 <- read_excel("brutos/base_orcid_2020.xlsx")


simon_muhsen <- read_excel("brutos/consolidado outubro 20 com 2022 - V2 (1).xlsx") 
simon_muhsen <- simon_muhsen %>% 
  filter(an_base == 2020) %>% 
  select("NM_ENTIDADE_ENSINO", "an_base", "CO_IES", "sigla_entidade_first", "QT_DOC_TOTAL", "QT_DOC_EXE", "QT_DOC_EX_FEMI", "QT_DOC_EX_MASC", "tipologia_2023")


ies <- simon_muhsen %>%
  select(NM_ENTIDADE_ENSINO, CO_IES, sigla_entidade_first,tipologia_2023) %>%
  distinct(sigla_entidade_first, .keep_all = TRUE)

ies[duplicated(ies$sigla_entidade_first), ]

# Limpando as variáveis para o join

base_orcid_2020$SIGLA <- tolower(trimws(base_orcid_2020$SIGLA))
base_orcid_2020$ies <- tolower(trimws(base_orcid_2020$ies))
base_orcid_2020$IES <- tolower(trimws(base_orcid_2020$IES))
ies$sigla_entidade_first <- tolower(trimws(ies$sigla_entidade_first))
ies$NM_ENTIDADE_ENSINO <- tolower(trimws(ies$NM_ENTIDADE_ENSINO))

ies <- ies[!duplicated(ies$sigla_entidade_first), ] #tirei duplicidades para não exceder os cruzamentos
ies <- ies[!duplicated(ies$NM_ENTIDADE_ENSINO), ]

# Tratando siglas e nomes de IES
padronizar <- function(x) {
  x <- str_replace_all(x, "/", "") 
  x <- str_replace_all(x, "-", "") 
  x <- str_replace_all(x, "\\s", "") 
  x
}

ies$sigla_entidade_first <- padronizar(ies$sigla_entidade_first)

# Cruzando as variáveis
orcid_ies_simon <- left_join(base_orcid_2020, ies, by = c("SIGLA" = "sigla_entidade_first")) #37915
orcid_ies_simon2 <- left_join(base_orcid_2020, ies, by = c("ies" = "NM_ENTIDADE_ENSINO")) #37915
orcid_ies_simon3 <- left_join(base_orcid_2020, ies, by = c("IES" = "NM_ENTIDADE_ENSINO"))

resultado <- anti_join(orcid_ies_simon2, orcid_ies_simon, by = c("CO_IES", "tipologia_2023")) 
resultado2 <- anti_join(orcid_ies_simon3, orcid_ies_simon2, orcid_ies_simon, by = c("CO_IES", "tipologia_2023")) 

orcid_ies_simon_complementado <- bind_rows(orcid_ies_simon, resultado, resultado2) 

orcid_ies_simon_complementado_unico <- orcid_ies_simon_complementado %>% 
  group_by(path) %>% 
  distinct(CO_IES, .keep_all = TRUE)

# Análise Manual - expansão das ies
joao <- read_excel("ies_vazias_joao.xlsx")
final <- bind_rows(orcid_ies_simon_complementado_unico, joao)

joao_unique <- joao[!duplicated(joao$CO_IES), ]

base_semiesnas <- final %>%
  filter(!is.na(CO_IES) & CO_IES != -1) 

tipologia_ies <- base_semiesnas %>%
  group_by(tipologia_2023) %>%
  summarise(Quantidade_IES = n_distinct(CO_IES))

tipologia_docentes <- base_semiesnas %>%
  group_by(tipologia_2023) %>%
  summarise(Quantidade_IES = n_distinct(path))

universidades <- as.data.frame(table(final$SIGLA))%>%
  arrange(desc(Freq))
regioes <- as.data.frame(table(final$Região))%>%
  arrange(desc(Freq))
cidades <- as.data.frame(table(final$organization_city_padrao))%>%
  arrange(desc(Freq))
uf <- as.data.frame(table(final$UF))%>%
  arrange(desc(Freq))

list_of_dfs <- list(
  Universidades = universidades,
  Regioes = regioes,
  Cidades = cidades,
  UF = uf
)

siglas_sem_coies <- base_semiesnas %>% 
  filter(is.na(CO_IES)) %>% 
  distinct(SIGLA, .keep_all = TRUE)

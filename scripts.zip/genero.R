pacman::p_load("genderBR", "gender", "genderizer", "geobr", "maps", "ggmap","writexl", "readxl", "readr", "dplyr", "tidyr", "tidyverse", "ggplot2", "stringr")

setwd("C:/Users/danie/Projetos R/Fapesp/frente 3/EBBC/muhsen")

base <- read_excel("finais/base_orcid_final_rev_Ana.xlsx")

extrair_primeiro_nome <- function(nome_completo) {
  # Verifica se o nome contém uma vírgula
  if (grepl(",", nome_completo)) {
    # Se existir uma vírgula, extrai o nome após a vírgula
    primeiro_nome <- trimws(strsplit(nome_completo, ",")[[1]][2])
  } else {
    # Se não existir vírgula, extrai o primeiro nome antes do primeiro espaço
    primeiro_nome <- strsplit(nome_completo, " ")[[1]][1]
  }
  return(primeiro_nome)
}

# Extrair o primeiro nome 
base$first_name <- sapply(base$name.x, extrair_primeiro_nome)

# Inferir o gênero 
base$gender <- get_gender(base$first_name)

# Identificando gênero para nomes que não foram identificados pelo genderBR
base$gender_other <- ifelse(is.na(base$gender),
                            gender::gender(base$first_name, method = "ssa")$gender,
                            base$gender)

# Identificar gênero para nomes restantes 
base$gender_final <- ifelse(is.na(base$gender_other),
                            genderizeR::findGivenNames(base$first_name)$gender,
                            base$gender_other)
base <- base %>%
  mutate(gender_final = coalesce(gender, gender_other, gender_final))

lattes <- read_excel("genero identidade lattes.xlsx")

lattes <- lattes %>%
  mutate(Genero = recode(Genero,
                         "masculino" = "Male",
                         "feminino" = "Female"))  
lattes_unique <- lattes %>%
  select(name.x, Genero) %>%
  distinct(name.x, .keep_all = TRUE)  

base_unique <- base %>%
  distinct(name.x, .keep_all = TRUE)  

base_genero <- base_unique %>%
  left_join(lattes_unique, by = "name.x") %>%  
  mutate(gender_final = ifelse(is.na(gender_final), Genero, gender_final)) %>%  
  select(-Genero) 

base <- base %>% 
  select(-gender, -gender_other)

base$gender_final <- tolower(base$gender_final)

base <- base %>%
  mutate(gender_final = ifelse(grepl("^[A-Z](\\.)\\s*([A-Z](\\.)\\s*){0,}[A-Z]?(\\s*,.*)?$", first_name, ignore.case = TRUE), NA, gender_final))

# Análise manual

sexo_joao <- read_excel("C:/Users/danie/Projetos R/Fapesp/frente 3/EBBC/muhsen/biblios/sem_genero_gabriel.xlsx")
sexo_joao <- sexo_joao[!duplicated(sexo_joao$name.x), ]


merged_sexo <- merge(base, sexo_joao, by = "name.x", all.x = TRUE)

# Substituir gender_final de base com o valor de gender_final de sexo_joao quando houver correspondência
merged_sexo$gender_final.x <- ifelse(!is.na(merged_sexo$gender_final.y), 
                                     merged_sexo$gender_final.y, 
                                     merged_sexo$gender_final.x)

# Manter apenas as colunas necessárias
merged_sexo <- merged_sexo[, !(names(merged_sexo) %in% c("gender_final.y"))]

merged_sexo <- merged_sexo[, !grepl("\\.y$", names(merged_sexo))]

writexl::write_xlsx(merged_sexo, "biblios/base_final_biblios.xlsx")

vinculos_sexo <- merged_sexo %>%
  group_by(path.x, gender_final.x) %>%
  summarise(Qtd = n_distinct(CO_IES.x)) 

# Contar a frequência de cada número de vínculos por gênero
numero_vinculos_sexo <- vinculos_sexo %>%
  group_by(path.x, gender_final.x, Qtd) %>%
  summarise(Frequencia = n()) %>%
  ungroup()

# Visualizar o resultado
print(numero_vinculos_sexo)

vinculos_sexo_contagem <- as.data.frame(table(numero_vinculos_sexo$gender_final.x, numero_vinculos_sexo$Qtd, numero_vinculos_sexo$Frequencia))

# Perfis Ana por gênero
merged_sexo$`Rev AMC` <- tolower(merged_sexo$`Rev AMC.x`)
perfis_sexo <- as.data.frame(table(merged_sexo$`Rev AMC.x`, merged_sexo$gender_final.x))

perfis_sexo <- perfis_sexo %>%
  pivot_wider(names_from = Var2, values_from = Freq, values_fill = list(Freq = 0)) %>%
  rename(perfil = Var1, mulher = female, homem = male) 

cidades_vinculos <- merged_sexo %>%
  group_by(path.x) %>%
  summarise(n_cidades = n_distinct(organization_city_padrao.x)) 


tipos_ies_cidade <- merged_sexo %>%
  group_by(tipologia_2023.x) %>%  
  summarise(
    num_cidades = n_distinct(organization_city_padrao.x),  
    num_docentes = n_distinct(path.x)  
  )










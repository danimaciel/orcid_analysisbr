pacotes <- c("geobr", "widyr", "igraph", "ggraph", "tidyr", "SnowballC", "stopwords", "tm", "tidytext", "lubridate", "ggthemes", "treemapify", "openxlsx", "rgdal", "sp", "geobr", "maps", "ggmap", "wordcloud", "stopwords", "tm", "plm", "ggplot2", "tidyverse", "dplyr", "readr","readxl", "lme4", "data.table", "tidyr", "stringr")
lapply(pacotes, require, character.only = TRUE)

setwd("C:/Users/danie/Projetos R/Fapesp/frente 3")

# Chamando os arquivos

orcid_emprego <- read_excel("orcid/orcid_employment_in_brazil.xlsx", sheet = 3)
df_orcid <- subset(orcid_emprego, select = -c(...18, ...19))
lista1 <- read_excel("List of Academic Ranksv2.xlsx")
lista2 <- read_excel("List of Academic Ranksv2.xlsx", sheet = 2)
lista_pt1 <- read_excel("List of Academic Ranksv2.xlsx", sheet = 3)
lista_pt2 <- read_excel("List of Academic Ranksv2.xlsx", sheet = 4)

# convertendo para minusc
lista1 <- as.data.frame(lapply(lista1, tolower))
lista2 <- as.data.frame(lapply(lista2, tolower))
lista_pt1 <- as.data.frame(lapply(lista_pt1, tolower))
lista_pt2 <- as.data.frame(lapply(lista_pt2, tolower))

# Trabalhando com as listas
prof_eng <- c(lista1$titulo, lista2$titulo)
prof_pt <- c(lista_pt1$titulo, lista_pt2$titulo)
lista_unica <- c(prof_eng, prof_pt)

find_match <- function(role) {
  if (is.na(role)) return(NA)  #Retorna NA se "role" estiver vazio
  
  for (term in lista_unica) {
    if (!is.na(term) && grepl(term, role, ignore.case = TRUE)) {
      return(term)
    }
  }
  
  return(NA)  
}


df_orcid <- df_orcid %>%
  mutate(palavra_lista = sapply(role, find_match))

df_orcid <- df_orcid %>%
  filter(!is.na(palavra_lista))


# palavra subsequente - Função para encontrar a palavra subsequente
find_following_words <- function(role, match) {
  if (is.na(role) || is.na(match)) return(NA)
  start_pos <- regexpr(match, role, ignore.case = TRUE)[1]
  end_pos <- start_pos + nchar(match) - 1
  following_words <- str_extract_all(substr(role, end_pos + 1, nchar(role)), "\\b\\w+\\b")[[1]]
  return(ifelse(length(following_words) >= 4, paste(following_words[1:4], collapse=" "), NA))
}

# Adiciona as 4 palavras subsequentes ao dataframe df_orcid
df_orcid <- df_orcid %>%
  mutate(palavra_subsequente = mapply(find_following_words, role, palavra_lista))

# normalizando municípios e regiões
municipios_ibge <- read_excel("municipios_ibge.xlsx")

#começando - transformando para minúscula e removendo acentuação
library(stringi)

padronizar_string <- function(x) {
  x <- tolower(x)  
  x <- stri_trans_general(x, "Latin-ASCII")  
  return(x)
}

df_orcid$organization_city_padrao <- sapply(df_orcid$organization_city, padronizar_string)
municipios_ibge$municipios_padrao <- sapply(municipios_ibge$Município, padronizar_string)

df_orcid <- df_orcid %>%
  left_join(select(municipios_ibge, municipios_padrao, UF, Região),
            by = c("organization_city_padrao" = "municipios_padrao"))

# normalizando universidades
universidades <- read.csv2("universidades.csv")#https://gist.github.com/alexandremcosta/c9361cc23722a5aa1133#file-universidades-csv
universidades <- data.frame(lapply(universidades, tolower))

padronizar_string_ies <- function(x) {
  x <- tolower(x)  
  x <- stri_trans_general(x, "Latin-ASCII")  
  return(x)
}

df_orcid$ies <- sapply(df_orcid$organization_name, padronizar_string_ies)
universidades$ies2 <- sapply(universidades$IES, padronizar_string_ies)

df_orcid <- df_orcid %>%
  left_join(select(universidades, IES, SIGLA, ies2),
            by = c("ies" = "ies2"))

#situação inesperada para universidade acompanhada de faculdade/instituto
correct_university <- function(df, pattern, new_IES, new_SIGLA) {
  matches <- grepl(pattern, df$ies)
  df$IES[matches] <- new_IES
  df$SIGLA[matches] <- new_SIGLA
  return(df)
}

df_orcid <- correct_university(df_orcid, "universidade de sao paulo", "universidade de sao paulo", "usp")
df_orcid <- correct_university(df_orcid, "universidade de campinas", "universidade de campinas", "unicamp")
df_orcid <- correct_university(df_orcid, "faculdade de tecnologia de sao paulo", "faculdade de tecnologia do estado de sao paulo", "fatec")
df_orcid <- correct_university(df_orcid, "universidade do estado de minas gerais", "universidade do estado de minas gerais", "uemg")
df_orcid <- correct_university(df_orcid, "universidade de brasilia", "universidade de brasilia", "unb")
df_orcid <- correct_university(df_orcid, "universidade estadual paulista", "universidade estadual paulista julio de mesquita filho", "unesp")



# identificando as ocorrências para usp
df_orcid <- df_orcid %>%
  mutate(
    IES = ifelse(grepl("usp", ies, ignore.case = TRUE), "universidade de sao paulo", IES),
    SIGLA = ifelse(grepl("usp", ies, ignore.case = TRUE), "USP", SIGLA)
  )


# identificando todas as ocorrências para usp
df_orcid <- df_orcid %>%
  mutate(
    IES = ifelse(grepl("ufscar", ies, ignore.case = TRUE), "universidade federal de sao carlos", IES),
    SIGLA = ifelse(grepl("ufscar", ies, ignore.case = TRUE), "ufscar", SIGLA)
  )


df_orcid <- df_orcid %>%
  mutate(
    IES = ifelse(grepl("ufmg", ies, ignore.case = TRUE), "universidade federal de minas gerais", IES),
    SIGLA = ifelse(grepl("ufmg", ies, ignore.case = TRUE), "ufmg", SIGLA)
  )


df_orcid <- df_orcid %>%
  mutate(
    IES = ifelse(grepl("unesp", ies, ignore.case = TRUE), "universidade estadual paulista julio de mesquita filho
", IES),
    SIGLA = ifelse(grepl("unesp", ies, ignore.case = TRUE), "unesp", SIGLA)
  )


df_orcid <- df_orcid %>%
  mutate(
    IES = ifelse(grepl("unb", ies, ignore.case = TRUE), "universidade de brasilia", IES),
    SIGLA = ifelse(grepl("unb", ies, ignore.case = TRUE), "unb", SIGLA)
  )

df_orcid <- df_orcid %>%
  mutate(
    IES = ifelse(grepl("ufrj", ies, ignore.case = TRUE), "universidade federal do rio de janeiro", IES),
    SIGLA = ifelse(grepl("ufrj", ies, ignore.case = TRUE), "ufrj", SIGLA)
  )

df_orcid <- df_orcid %>%
  mutate(
    IES = ifelse(grepl("ufac", ies, ignore.case = TRUE), "universidade federal do acre", IES),
    SIGLA = ifelse(grepl("ufac", ies, ignore.case = TRUE), "ufac", SIGLA)
  )

df_orcid <- df_orcid %>%
  mutate(
    IES = ifelse(grepl("unifesp", ies, ignore.case = TRUE), "universidade federal de sao paulo", IES),
    SIGLA = ifelse(grepl("unifesp", ies, ignore.case = TRUE), "unifesp", SIGLA)
  )


# tirando secretarias e governo

df_orcid2 <- df_orcid %>%
  filter(!grepl("secretaria|governo|colégio|colegio|escola|secretria|secretatia|secretary|secrertaria|secretraria|secretaira", ies, ignore.case = TRUE))

# separando os roles por instituição
secretarias_df <- professors_df %>%
  filter(grepl("secretaria|governo|colégio", ies, ignore.case = TRUE))


# Verificação
prof_role_lista <- as.data.frame(table(df_orcid$palavra_lista))
prof_role_lista$Var1 <- tolower(prof_role_lista$Var1)
cidades_lista <- as.data.frame(table(df_orcid$organization_city_padrao))
regioes_lista <- as.data.frame(table(df_orcid$Região))
univ_lista <- as.data.frame(table(df_orcid$ies))
uf_lista <- as.data.frame(table(df_orcid$UF))
univ_organization_name_lista <- as.data.frame(table(df_orcid$organization_name))
ano_lista <- as.data.frame(table(df_orcid$end_date_year))

professors_df2 %>% 
  filter(is.na(end_date_year))

variaveis_distintas_lista <- list(
  Roles = prof_role_lista,
  Cidades = cidades_lista,
  Regioes = regioes_lista,
  Universidades = univ_lista,
  uf_lista = uf_lista
)





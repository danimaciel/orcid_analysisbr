pacman::p_load("geobr", "maps", "ggmap","writexl", "readxl", "readr", "dplyr", "tidyr", "tidyverse", "ggplot2", "stringr")

setwd("C:/Users/danie/Projetos R/Fapesp/frente 3/EBBC/muhsen")

base <- read_excel("biblios/final_merged2.xlsx") #25125 registros, 23850 únicos

base_nas <- sapply(base, function(x) sum(is.na(x)))

print(base_nas)

perfil <- read_excel("finais/perfis_ana.xlsx", # verificação manual
                     sheet = "Perfil3")

# Realizando a junção e atualização com base na rev AMC
base2 <- base %>%
  left_join(perfil %>% select(Var1, Var2, titulação, `rev AMC`), by = c("role.x" = "Var1", "palavra_lista" = "Var2")) %>%
  mutate(`Rev AMC` = `rev AMC`) %>%
  select(-`rev AMC`)

base2 <- base2 %>% 
  filter(`Rev AMC` != "NÃO É DOCENTE") #base final - 25063

titulacao <- as.data.frame(table(base2$titulação)) 

base_unicos <- base2 %>% 
  distinct(path, .keep_all= TRUE) #23793 únicos

base_unicos_nas <- sapply(base_unicos, function(x) sum(is.na(x)))

percentages <- sapply(base, function(x) {
  total <- length(x)
  na_count <- sum(is.na(x))
  empty_count <- sum(x == "" | x == " ")
  filled_count <- total - na_count - empty_count
  percent_filled <- (filled_count / total) * 100
  percent_na <- (na_count / total) * 100
  percent_empty <- (empty_count / total) * 100
  return(c(Percent_Filled = percent_filled, Percent_NA = percent_na, Percent_Empty = percent_empty))
})

base2$Região[is.na(base2$Região) | base2$Região == "" | base2$Região == " "] <- "Não Identificado"
base2$organization_city.x[is.na(base2$organization_city.x) | base2$organization_city.x == "" | base2$organization_city.x == " "] <- "Não Identificado"
base2$UF[is.na(base2$UF) | base2$UF == "" | base2$UF == " "] <- "Não Identificado"

# Exibir o resultado em percentagens
print(percentages)

# qual a cobertura dos registros da base ORCID em relação às ocupações acadêmicas (carreira docente) das instituições de ensino superior no Brasil? comparação com dados censitários do INEP - do total de pessoas, x% atua como docente e outras ocupações relacionadas -------------------

vinculos <- base2 %>%
  group_by(path) %>%
  summarise(Qtd = n_distinct(SIGLA)) 

numero_vinculos <- vinculos %>%
  group_by(Qtd) %>%
  summarise(Frequencia = n()) %>%
  ungroup()

perfis_diferentes <- base2 %>%
  group_by(path) %>%
  summarise(number_of_roles = n_distinct(`Rev AMC`))

numero_perfis_diferentes <- as.data.frame(table(perfis_diferentes$number_of_roles))

perfis_ana <- as.data.frame(table(base2$`Rev AMC`))

# qual a distribuição geográfica dos registros -------------------
uf <- as.data.frame(table(base2$UF))
estados <- read_state(code_state = "all", year = 2020)

dados_mapa <- left_join(estados, uf, by = c("abbrev_state" = "Var1"))

mapa <- ggplot(dados_mapa) +
  geom_sf(aes(fill = Freq), color = NA) + 
  theme_minimal() +
  scale_fill_gradient(low = "lightblue", high = "darkblue", name = "Número de Registros") +
  labs(fill = "Número de Registros",
       title = "Distribuição de Docentes por Estado",
       subtitle = "Dados da base ORCID")

mapa

# Qual a distribuição dos registros em termos de formação acadêmica (doutorado) - cruzar com a base qualificação/educação -----------------
base2$`Rev AMC` <- tolower(base2$`Rev AMC`)
perfis_ana <- as.data.frame(table(base2$`Rev AMC`))
perfis_ana_tipo_ies <- as.data.frame(table(base2$`Rev AMC`, base2$tipologia_2023.x)) 

perfis_ana_tipo_ies <- perfis_ana_tipo_ies %>% 
  filter(Freq > 0) %>% 
  filter(Var2 != "99") %>%  # Adiciona esta linha para excluir o tipo específico
  group_by(Var1) %>% 
  slice_max(order_by = Freq, n = 3) %>%
  ungroup()

perfis_ana_tipo_ies2 <- perfis_ana_tipo_ies2_esp %>% 
  filter(Freq > 0) %>% 
  group_by(Var1) %>% 
  slice_max(order_by = Freq, n = 3) %>%
  ungroup()

base_co_ies <- base2 %>% 
  filter(!is.na(CO_IES.x)& CO_IES.x !=-1)


contagem_ies <- base2 %>%
  group_by(CO_IES.x, SIGLA, IES) %>%  
  summarise(Quantidade = n()) %>%  
  ungroup() %>% 
  arrange(desc(Quantidade)) 

contagem_ies$SIGLA <- toupper(contagem_ies$SIGLA )
contagem_ies$IES <- toupper(contagem_ies$IES)

# Vendo quem está ativo em mais de uma IES 
ies_por_docente <- base2 %>%
  group_by(path) %>%  
  summarise(quantidade_ies = n_distinct(CO_IES.x)) %>%  
  ungroup() 

docentes_por_ies <- base2 %>%
  group_by(CO_IES.x, SIGLA) %>%  
  summarise(quantidade_docentes = n_distinct(path)) %>%  
  ungroup()  %>% 
  arrange(desc(quantidade_docentes))

tipologia_ies <- base2 %>%
  group_by(tipologia_2023.x) %>%
  summarise(Quantidade_IES = n_distinct(CO_IES.x))

tipologia_docentes <- base2 %>%
  group_by(tipologia_2023.x) %>%
  summarise(Quantidade_IES = n_distinct(path))

regioes <- as.data.frame(table(base2$Região))%>%
  arrange(desc(Freq))

cidades <- as.data.frame(table(base2$organization_city_padrao))%>%
  arrange(desc(Freq))
uf <- as.data.frame(table(base2$UF))%>%
  arrange(desc(Freq))

list_of_dfs <- list(
  Universidades = contagem_ies,
  Regioes = regioes,
  Cidades = cidades,
  UF = uf,
  Perfis = perfis_ana_tipo_ies,
  Docentes_IES = docentes_por_ies
)

write_xlsx(list_of_dfs, path = "finais/Dados_Analise2.xlsx")
write_xlsx(base2, "finais/base_orcid_final_rev_Ana.xlsx")
